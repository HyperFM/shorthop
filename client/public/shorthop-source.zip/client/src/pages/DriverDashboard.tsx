import { useState, useRef, useEffect } from "react";
import { SeasonalGreeting } from "@/components/SeasonalGreeting";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Map, Clock, Calendar, Check, X, Plus, Play, Route as RouteIcon, MapPin, CarFront, Share2, Flame, Award, Star, Power, Shield, AlertTriangle, Smartphone, Navigation, LocateFixed } from "lucide-react";
import { motion } from "framer-motion";
import { MatchFoundModal } from "@/components/MatchFoundModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useRoutes, useCreateRoute, useDeleteRoute } from "@/hooks/use-routes";
import { useHops, useAcceptHop, useCompleteHop } from "@/hooks/use-hops";
import { TrustedHoppers } from "@/components/TrustedHoppers";
import { ShareRideCard } from "@/components/ShareRideCard";
import { useGeolocation, useLiveLocationBroadcast, useHopTracking } from "@/hooks/use-location";
import { apiRequest } from "@/lib/queryClient";
import { showFlash } from "@/components/FlashNotification";
import { playDriverApproachingSound } from "@/lib/sounds";
import { DriverRoadSideNotice, buildRoadSideInfo, findCorridorByName } from "@/components/RoadSideGuide";
import { DriverQuestionnaire } from "@/components/DriverQuestionnaire";
import { useLocation } from "wouter";
import type { User } from "@shared/routes";
import type { ShortHop } from "@shared/schema";

function getBadgeStyle(badge: string): { icon: typeof Flame; color: string } {
  if (badge.includes("100")) return { icon: Award, color: "text-red-600" };
  if (badge.includes("50")) return { icon: Flame, color: "text-red-500" };
  if (badge.includes("25")) return { icon: Flame, color: "text-orange-600" };
  if (badge.includes("10")) return { icon: Flame, color: "text-orange-500" };
  if (badge.includes("3")) return { icon: Star, color: "text-yellow-500" };
  if (badge.includes("Founding")) return { icon: Award, color: "text-green-500" };
  return { icon: Award, color: "text-blue-500" };
}

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const routeSchema = z.object({
  name: z.string().min(1, "Name is required"),
  startLocation: z.string().min(1, "Start location is required"),
  endLocation: z.string().min(1, "End location is required"),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  days: z.array(z.string()).min(1, "Select at least one day"),
});

type DriverStatus = {
  isDriver: boolean;
  isActive: boolean;
  driverVerified: boolean;
  vehicleMake: string | null;
  applicationStatus: string | null;
};

export default function DriverDashboard({ user }: { user: User }) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: routes } = useRoutes();
  const { data: hops } = useHops();
  const createRoute = useCreateRoute();
  const deleteRoute = useDeleteRoute();
  const acceptHop = useAcceptHop();
  const completeHop = useCompleteHop();

  const { data: driverStatus } = useQuery<DriverStatus>({
    queryKey: ['/api/driver/status'],
    refetchInterval: 5000,
  });

  const toggleActive = useMutation({
    mutationFn: async (active: boolean) => {
      await apiRequest("POST", "/api/driver/active", { active });
    },
    onSuccess: (_data, active) => {
      queryClient.invalidateQueries({ queryKey: ['/api/driver/status'] });
      queryClient.invalidateQueries({ queryKey: ['/api/me'] });
      showFlash(active ? "🟢" : "🔴", active ? "You're active!" : "You're offline", active ? "success" : "info");
    },
    onError: (err: any) => {
      showFlash("⚠️", err?.message || "Can't toggle status", "error");
    },
  });

  const { data: badges } = useQuery<{ id: number; badge: string; earnedAt: string | null }[]>({
    queryKey: ['/api/profile/badges'],
  });
  
  const hasMatchedHop = hops?.some(h => h.status === 'matched') ?? false;
  useLiveLocationBroadcast(hasMatchedHop || (driverStatus?.isActive ?? false));
  
  const [isRouteOpen, setIsRouteOpen] = useState(false);
  const [completedHopForShare, setCompletedHopForShare] = useState<ShortHop | null>(null);
  const [driverCurrentLoc, setDriverCurrentLoc] = useState("");
  const [driverDestination, setDriverDestination] = useState("");
  const [showDriverMatchModal, setShowDriverMatchModal] = useState(false);
  const driverPrevActiveHopCountRef = useRef<number>(0);
  const [driverTripActive, setDriverTripActive] = useState(false);

  const form = useForm<z.infer<typeof routeSchema>>({
    resolver: zodResolver(routeSchema),
    defaultValues: {
      name: "", startLocation: "", endLocation: "", startTime: "", endTime: "", days: []
    }
  });

  const onSubmitRoute = (data: z.infer<typeof routeSchema>) => {
    createRoute.mutate(data, {
      onSuccess: () => {
        setIsRouteOpen(false);
        form.reset();
      }
    });
  };

  const availableHops = hops?.filter(h => h.status === 'requested') || [];
  const activeHops = hops?.filter(h => h.status === 'matched' || h.status === 'in_ride') || [];
  const currentActiveHop = activeHops[0];

  useEffect(() => {
    const currentCount = activeHops.length;
    if (currentCount > driverPrevActiveHopCountRef.current && currentCount > 0) {
      setShowDriverMatchModal(true);
      if (navigator.vibrate) {
        navigator.vibrate([200, 100, 200, 100, 400]);
      }
    }
    driverPrevActiveHopCountRef.current = currentCount;
  }, [activeHops.length]);

  const geo = useGeolocation();
  const tracking = useHopTracking(currentActiveHop?.id, !!(currentActiveHop && (currentActiveHop.status === 'matched' || currentActiveHop.status === 'in_ride')));
  const driverDropoffSoundRef = useRef(false);
  const driverPrevDistRef = useRef<number | null>(null);
  const [driverIsConverging, setDriverIsConverging] = useState(false);
  const [driverIsTravelingTogether, setDriverIsTravelingTogether] = useState(false);

  useEffect(() => {
    if (tracking.distance !== null && tracking.distance !== undefined) {
      if (driverPrevDistRef.current !== null) {
        const delta = driverPrevDistRef.current - tracking.distance;
        if (Math.abs(delta) > 0.005) {
          const closing = delta > 0;
          setDriverIsConverging(closing);
          if (closing && tracking.distance < 0.05) {
            setDriverIsTravelingTogether(true);
          }
        }
      }
      driverPrevDistRef.current = tracking.distance;
    }
  }, [tracking.distance]);

  useEffect(() => {
    driverPrevDistRef.current = null;
    setDriverIsConverging(false);
    setDriverIsTravelingTogether(false);
  }, [currentActiveHop?.id, currentActiveHop?.status]);

  const startRideAsDriver = useMutation({
    mutationFn: async (hopId: number) => {
      const res = await apiRequest("POST", `/api/hops/${hopId}/start-ride`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/hops'] });
      showFlash("🚗", "Ride started!", "success");
    },
  });

  useEffect(() => {
    if (currentActiveHop?.status === 'matched') {
      driverDropoffSoundRef.current = false;
    }
    if (currentActiveHop?.status === 'in_ride' && geo.latitude && geo.longitude && !driverDropoffSoundRef.current) {
      const endLat = parseFloat((currentActiveHop as any).endLat || "0");
      const endLng = parseFloat((currentActiveHop as any).endLng || "0");
      if (endLat && endLng) {
        const R = 3959;
        const dLat = (endLat - geo.latitude) * Math.PI / 180;
        const dLon = (endLng - geo.longitude) * Math.PI / 180;
        const a = Math.sin(dLat / 2) ** 2 + Math.cos(geo.latitude * Math.PI / 180) * Math.cos(endLat * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
        const distToDestMiles = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        if (distToDestMiles < 0.15) {
          driverDropoffSoundRef.current = true;
          playDriverApproachingSound();
          if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 300]);
          showFlash("📍", "Approaching hopper's drop-off!", "success");
        }
      }
    }
  }, [currentActiveHop?.status, geo.latitude, geo.longitude]);

  const isVerified = driverStatus?.driverVerified ?? false;
  const isActiveNow = driverStatus?.isActive ?? false;
  const appStatus = driverStatus?.applicationStatus;
  const needsOnboarding = !driverStatus?.vehicleMake && !appStatus;

  return (
    <div className="px-4 pt-3 pb-6 max-w-lg mx-auto space-y-4">

      <MatchFoundModal
        visible={showDriverMatchModal}
        role="driver"
        destination={currentActiveHop?.endLocation || undefined}
        onDismiss={() => setShowDriverMatchModal(false)}
        onViewTrip={() => {}}
      />

      
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-start justify-between gap-3"
      >
        <div>
          <div className="flex items-center gap-2">
            <SeasonalGreeting username={user.username} testId="text-driver-title" role="driver" />
            {user.isFounder && user.founderBadge && (
              <Badge className="bg-gradient-to-r from-orange-500 to-green-500 text-white border-0 text-[8px] px-1 py-0 self-end mb-0.5" data-testid="badge-founder">
                Founder
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">Help people along your route.</p>
        </div>
        <Card className="border-secondary/30 bg-gradient-to-br from-secondary/10 to-transparent shrink-0 cursor-pointer hover:border-secondary/50 transition-colors" onClick={() => setLocation("/rewards")} data-testid="card-wheels-badge">
          <CardContent className="p-2.5 flex items-center gap-2.5">
            <motion.div
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="w-9 h-9 rounded-xl bg-gradient-to-br from-secondary to-orange-600 flex items-center justify-center text-white shadow-sm"
            >
              <span className="text-base">🛞</span>
            </motion.div>
            <div>
              <div className="text-[10px] font-bold text-secondary uppercase tracking-wider">Earnings</div>
              <div className="text-lg font-black text-foreground leading-none">${(user.driverEarnings || 0).toFixed(2)}</div>
            </div>
          </CardContent>
        </Card>
      </motion.div>


      {isVerified && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
          <Card className={`border-2 transition-colors ${isActiveNow ? 'border-green-400 bg-green-50/30' : 'border-border/50'}`} data-testid="card-active-toggle">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                    isActiveNow ? 'bg-gradient-to-br from-green-400 to-green-600' : 'bg-muted'
                  }`}>
                    <Power className={`w-5 h-5 ${isActiveNow ? 'text-white' : 'text-muted-foreground'}`} />
                  </div>
                  <div>
                    <p className="text-sm font-bold" data-testid="text-active-status">
                      {isActiveNow ? "You're Active" : "You're Offline"}
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      {isActiveNow ? "Hoppers can see you and request rides" : "Go active to start accepting hops"}
                    </p>
                  </div>
                </div>
                <Button
                  className={`h-11 px-5 font-bold text-sm rounded-xl shadow-sm ${
                    isActiveNow
                      ? 'bg-red-500 hover:bg-red-600 text-white'
                      : 'bg-gradient-to-r from-green-500 to-green-600 text-white'
                  }`}
                  onClick={() => {
                    if (isActiveNow) {
                      toggleActive.mutate(false);
                    } else {
                      setLocation("/instahop?mode=drive");
                    }
                  }}
                  disabled={toggleActive.isPending}
                  data-testid="button-toggle-active"
                >
                  {toggleActive.isPending ? '...' : isActiveNow ? 'GO OFFLINE' : 'GO ACTIVE'}
                </Button>
              </div>
              {isActiveNow && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-3 pt-3 border-t border-green-200"
                >
                  <div className="flex items-center gap-2">
                    <motion.div
                      className="w-2 h-2 rounded-full bg-green-500"
                      animate={{ scale: [1, 1.4, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    />
                    <span className="text-xs text-green-700 font-medium">Broadcasting your location to nearby hoppers</span>
                  </div>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}

      {isVerified && !(user as any).driverQuestionnaireCompleted && (
        <DriverQuestionnaire
          onComplete={() => {}}
          initialValues={{
            driverConvoComfort: (user as any).driverConvoComfort,
            driverMusicPref: (user as any).driverMusicPref,
            driverPetsOk: (user as any).driverPetsOk,
            driverGroceriesOk: (user as any).driverGroceriesOk,
            driverLifestyleTags: (user as any).driverLifestyleTags,
          }}
        />
      )}

      <div
        className="bg-gradient-to-r from-primary/5 to-green-500/5 border border-primary/15 rounded-2xl px-4 py-3"
        data-testid="card-driver-philosophy"
      >
        <p className="text-sm text-foreground font-medium">Help people along your route.</p>
        <p className="text-xs text-muted-foreground mt-0.5">Earn Wheels you can cash out anytime.</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="flex-1"
        >
          <Card className="game-card border-orange-500/30 bg-gradient-to-br from-orange-500/10 via-orange-500/5 to-transparent hover:border-orange-500/50">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white shadow-lg shadow-orange-500/30">
                <span className="text-2xl">🔥</span>
              </div>
              <div>
                <div className="text-xs font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider" data-testid="text-streak-label">Hop Streak</div>
                <div className="text-3xl font-black text-foreground" data-testid="text-streak-count">{user.hopStreak || 0}</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="flex-1"
        >
          <Card className="game-card border-primary/30 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent hover:border-primary/50">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white shadow-lg shadow-primary/30">
                <span className="text-2xl">⭐</span>
              </div>
              <div>
                <div className="text-xs font-bold text-primary uppercase tracking-wider" data-testid="text-total-hops-label">Total Hops</div>
                <div className="text-3xl font-black text-foreground" data-testid="text-total-hops-count">{user.totalHops || 0}</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {badges && badges.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="mb-8"
        >
          <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2" data-testid="text-badges-heading">
            🏆 Achievement Badges
          </h3>
          <div className="flex flex-wrap gap-2">
            {badges.map((b, i) => {
              const badgeInfo = getBadgeStyle(b.badge);
              const IconComponent = badgeInfo.icon;
              return (
                <motion.div key={b.id} initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.1 }}>
                  <Badge variant="secondary" className="gap-1.5 py-1.5 px-3 text-sm hover:scale-105 transition-transform cursor-default" data-testid={`badge-achievement-${b.id}`}>
                    <IconComponent className={`w-4 h-4 ${badgeInfo.color}`} />
                    {b.badge}
                  </Badge>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      )}

      <div className="grid lg:grid-cols-3 gap-8">
        

        {/* Middle Col */}
        <div className="lg:col-span-1 space-y-6">
        </div>

        {/* Right Col: Active & Available Hops */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Active hops are managed on InstaHop map screen */}


        </div>
      </div>

      <div className="flex gap-2 mt-4 mb-4">
        <Card className="flex-1 border-border/50 shadow-sm cursor-pointer hover:border-green-200 transition-colors" onClick={() => setLocation("/widget")} data-testid="card-widget-preview">
          <CardContent className="p-3 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
              <Smartphone className="w-4 h-4 text-green-600" />
            </div>
            <div>
              <p className="text-[11px] font-bold">Widget Preview</p>
              <p className="text-[9px] text-muted-foreground">iOS Home Screen</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {user.tier === "flexhop" && (
        <div className="grid lg:grid-cols-2 gap-8">
          <TrustedHoppers />
        </div>
      )}


      {completedHopForShare && (
        <Dialog open={!!completedHopForShare} onOpenChange={(open) => !open && setCompletedHopForShare(null)}>
          <DialogContent className="sm:max-w-md p-0 overflow-visible border-0 bg-transparent shadow-none">
            <ShareRideCard
              hop={completedHopForShare}
              username={user.username}
              onClose={() => setCompletedHopForShare(null)}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
